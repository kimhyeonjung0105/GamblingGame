class Player {
    string player;
public:
    void setName(string player);
    string getName() { return player; };
};

class GamblingGame {
    Player* p = new Player[2];
public:
    GamblingGame();
    void nameSet();
    string random(string n);
    void startGame();
    ~GamblingGame() { delete[] p; }
};