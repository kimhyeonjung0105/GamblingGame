#include<iostream>
#include<string>
#include <cstdlib>
#include <ctime>
using namespace std;

#include "GamblingGame_Class.h"

int main() {
    GamblingGame game;
    game.nameSet();
    game.startGame();
}